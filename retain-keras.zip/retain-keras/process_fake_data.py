import pickle
import numpy as np
import pandas as pd
import math
import sys
from sklearn.model_selection import train_test_split

if __name__ == '__main__':
    #out_directory = sys.argv[1]
    #train_proportion = sys.argv[2]
    # data point t
    TIME = 100
    NORM_TEMP = 37
    HIGH_TEMP = 40
    LOW_TEMP = 34
    OFFSET = 4

    N = 100

    mort = np.zeros(N)
    data=[]
    code_placeholder=np.zeros((N, TIME, 4))
    for n in range(N):
        health = np.zeros(TIME)
        med1 = np.zeros(TIME)
        med2 = np.zeros(TIME)
        temp = np.zeros(TIME)

        health[0] = np.random.normal() - OFFSET # come in with lower health status
        med1[0] = np.random.normal(5) # correct meds
        med2[0] = np.random.normal(5) # wrong meds
        temp[0] = NORM_TEMP + OFFSET

        np.random.normal(5)

        # generate the latent stats from medication
        # m_t = N( {m_{t_1},h_{t-1},t_{t-1}} )
        # h_t = N(h_{t-1} + 
        # t_t = 
        # 
        for i in range(1, TIME):
            med1[i] = max(np.random.normal(1.2*temp[i-1] - NORM_TEMP, 0.1), 0)
            med2[i] = max(np.random.normal(-0.8*temp[i-1] + NORM_TEMP, 0.1), 0)
            health[i] = np.random.normal(health[i-1] + 0.01 * med1[i] - 0.01 * med2[i], 0.2)
            temp[i] = max(np.random.normal(-health[i-1] + NORM_TEMP + OFFSET, 0.1), LOW_TEMP)
        # sigmoid on the latent health status
        mort[n] = np.random.binomial(1, 1/(1+math.exp((1-(temp[TIME-1]-NORM_TEMP-1)))))

        data.append(np.transpose(np.array([med1, med2, health, temp])).tolist())
    print(np.sum(mort))
    all_data = pd.DataFrame(data={'codes': code_placeholder.tolist(), 'numerics':data}, columns=['codes', 'numerics']).reset_index()
    all_targets = pd.DataFrame(data={'target': mort.tolist()},columns=['target']).reset_index()

    #data_train,data_test = train_test_split(all_data, train_size=train_proportion, random_state=12345)
    #target_train,target_test = train_test_split(all_targets, train_size=train_proportion, random_state=12345)

    #data_train.sort_index().to_pickle(out_directory+'/data_train.pkl')
    #data_test.sort_index().to_pickle(out_directory+'/data_test.pkl')
    #target_train.sort_index().to_pickle(out_directory+'/target_train.pkl')
    #target_test.sort_index().to_pickle(out_directory+'/target_test.pkl')